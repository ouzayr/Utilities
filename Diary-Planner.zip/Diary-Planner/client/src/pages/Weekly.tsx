import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { format, startOfWeek, addDays, isSameDay, parseISO } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { TaskDetailsModal } from "@/components/TaskDetailsModal";
import { Loader2 } from "lucide-react";

export default function WeeklyPlanner() {
  const queryClient = useQueryClient();
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  
  const today = new Date();
  const weekStart = startOfWeek(today, { weekStartsOn: 1 });
  const weekDays = [0, 1, 2, 3, 4].map(i => addDays(weekStart, i));
  const weekEnd = addDays(weekStart, 6);

  const { data: tasks, isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const res = await fetch("/api/tasks");
      if (!res.ok) throw new Error("Failed to fetch tasks");
      return res.json();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      await apiRequest("PUT", `/api/tasks/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  const pendingTasks = useMemo(() => {
    return tasks?.filter(t => !t.completed && !t.cancelled) || [];
  }, [tasks]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary/30" />
      </div>
    );
  }

  return (
    <div className="container max-w-6xl py-12 font-serif">
      <TaskDetailsModal task={editingTask} onClose={() => setEditingTask(null)} />
      
      <h1 className="text-5xl font-bold italic text-primary mb-12 text-center">Weekly Planner</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-12">
        {weekDays.map((day) => {
          const dateStr = format(day, "yyyy-MM-dd");
          const dayTasks = tasks?.filter(t => t.date === dateStr) || [];
          
          return (
            <Card key={dateStr} className="bg-white/50 backdrop-blur-sm border-none shadow-lg">
              <CardHeader className="pb-2 text-center border-b border-dashed border-primary/10">
                <CardTitle className="text-xl font-bold italic text-primary">
                  {format(day, "EEEE")}
                </CardTitle>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">
                  {format(day, "MMM do")}
                </p>
              </CardHeader>
              <CardContent className="pt-4 px-4 space-y-3">
                {dayTasks.length === 0 ? (
                  <p className="text-xs text-muted-foreground italic text-center py-4">No entries.</p>
                ) : (
                  dayTasks.map(task => (
                    <div 
                      key={task.id} 
                      className={cn(
                        "flex items-start gap-2 text-sm group cursor-pointer",
                        task.completed && "opacity-50",
                        task.cancelled && "opacity-30"
                      )}
                      onClick={() => setEditingTask(task)}
                    >
                      <Checkbox
                        checked={task.completed}
                        onCheckedChange={(checked) => {
                          updateMutation.mutate({ id: task.id, updates: { completed: !!checked, cancelled: false } });
                        }}
                        className="mt-0.5 h-3.5 w-3.5"
                        onClick={(e) => e.stopPropagation()}
                      />
                      <span className={cn(
                        "flex-1 leading-tight",
                        task.completed && "line-through",
                        task.cancelled && "line-through"
                      )}>
                        {task.title}
                      </span>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-white/50 backdrop-blur-sm border-none shadow-xl relative overflow-hidden">
        <div className="absolute left-10 top-0 bottom-0 w-px bg-red-200/50" />
        <CardHeader className="pl-16">
          <CardTitle className="text-3xl font-bold italic text-primary">Pending This Week</CardTitle>
        </CardHeader>
        <CardContent className="pl-16 pr-12 pb-12 space-y-4">
          {pendingTasks.length === 0 ? (
            <p className="text-muted-foreground italic text-lg py-8">All clear for the week.</p>
          ) : (
            pendingTasks.map(task => (
              <div 
                key={task.id} 
                className="flex items-center gap-4 py-2 group cursor-pointer border-b border-dashed border-primary/10"
                onClick={() => setEditingTask(task)}
              >
                <Checkbox
                  checked={task.completed}
                  onCheckedChange={(checked) => {
                    updateMutation.mutate({ id: task.id, updates: { completed: !!checked, cancelled: false } });
                  }}
                  onClick={(e) => e.stopPropagation()}
                />
                <span className="flex-1 text-xl">{task.title}</span>
                <span className="text-xs text-muted-foreground font-sans uppercase tracking-widest">
                  {format(parseISO(task.date), "EEE")}
                </span>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
