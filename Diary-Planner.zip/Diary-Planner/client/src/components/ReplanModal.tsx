import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, X, ArrowRight } from "lucide-react";

export function ReplanModal() {
  const [open, setOpen] = useState(false);
  const today = format(new Date(), "yyyy-MM-dd");

  const { data: pastTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks/past-uncompleted", { today }],
    queryFn: async () => {
      const res = await fetch(`/api/tasks/past-uncompleted?today=${today}`);
      if (!res.ok) throw new Error("Failed to fetch past tasks");
      return res.json();
    },
  });

  useEffect(() => {
    if (pastTasks && pastTasks.length > 0) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  }, [pastTasks]);

  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      await apiRequest("PUT", `/api/tasks/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/past-uncompleted"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  if (!pastTasks || pastTasks.length === 0) return null;

  const currentTask = pastTasks[0];

  const handleComplete = () => {
    updateMutation.mutate({ id: currentTask.id, updates: { completed: true } });
  };

  const handleCancel = () => {
    updateMutation.mutate({ id: currentTask.id, updates: { cancelled: true } });
  };

  const handleMoveToToday = () => {
    const history = currentTask.rescheduleHistory || [];
    updateMutation.mutate({ 
      id: currentTask.id, 
      updates: { 
        date: today,
        rescheduleHistory: [...history, currentTask.date]
      } 
    });
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-[425px] font-serif">
        <DialogHeader>
          <DialogTitle className="text-2xl italic">Morning Reflection</DialogTitle>
          <DialogDescription>
            You have {pastTasks.length} uncompleted tasks from previous days. How shall we proceed?
          </DialogDescription>
        </DialogHeader>
        
        <Card className="my-4 border-dashed bg-muted/30">
          <CardContent className="pt-6">
            <p className="text-lg italic text-center">"{currentTask.title}"</p>
            <p className="text-xs text-muted-foreground text-center mt-2">from {currentTask.date}</p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 gap-2">
          <Button 
            variant="outline" 
            className="justify-start hover:bg-green-50 hover:text-green-700"
            onClick={handleComplete}
            disabled={updateMutation.isPending}
            data-testid="button-complete-task"
          >
            <Check className="mr-2 h-4 w-4" /> Mark Completed
          </Button>
          <Button 
            variant="outline" 
            className="justify-start hover:bg-blue-50 hover:text-blue-700"
            onClick={handleMoveToToday}
            disabled={updateMutation.isPending}
            data-testid="button-move-task"
          >
            <ArrowRight className="mr-2 h-4 w-4" /> Carry Over to Today
          </Button>
          <Button 
            variant="outline" 
            className="justify-start hover:bg-red-50 hover:text-red-700"
            onClick={handleCancel}
            disabled={updateMutation.isPending}
            data-testid="button-cancel-task"
          >
            <X className="mr-2 h-4 w-4" /> Cancel Task
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
