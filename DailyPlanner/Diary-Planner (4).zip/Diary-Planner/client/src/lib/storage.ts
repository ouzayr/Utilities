import { useState, useEffect, useCallback } from "react";
import { Task, InsertTask } from "@shared/schema";
import { format, isBefore, parseISO } from "date-fns";
import { apiRequest } from "./queryClient";

const STORAGE_KEY = 'diary-storage-v1';

// Simple global state to share between hooks
let globalTasks: Task[] = [];
const listeners: Set<(tasks: Task[]) => void> = new Set();

const updateGlobalTasks = (tasks: Task[]) => {
  globalTasks = tasks;
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ tasks }));
  listeners.forEach(l => l(tasks));
};

export function useTaskStore() {
  const [tasks, setTasks] = useState<Task[]>(globalTasks);

  useEffect(() => {
    const listener = (newTasks: Task[]) => setTasks(newTasks);
    listeners.add(listener);
    
    // Initial fetch if empty
    if (globalTasks.length === 0) {
      const fetchTasks = async () => {
        try {
          const res = await fetch("/api/tasks");
          if (res.ok) {
            const data = await res.json();
            updateGlobalTasks(data);
          } else {
            const saved = localStorage.getItem(STORAGE_KEY);
            if (saved) {
              const parsed = JSON.parse(saved);
              updateGlobalTasks(parsed.tasks || []);
            }
          }
        } catch (e) {
          const saved = localStorage.getItem(STORAGE_KEY);
          if (saved) {
            const parsed = JSON.parse(saved);
            updateGlobalTasks(parsed.tasks || []);
          }
        }
      };
      fetchTasks();
    }

    return () => {
      listeners.delete(listener);
    };
  }, []);

  const addTask = useCallback(async (insertTask: InsertTask) => {
    try {
      const res = await apiRequest("POST", "/api/tasks", insertTask);
      const newTask = await res.json();
      updateGlobalTasks([...globalTasks, newTask]);
      return newTask;
    } catch (e) {
      console.error("Failed to add task to backend", e);
    }
  }, []);

  const updateTask = useCallback(async (id: number, updates: Partial<InsertTask>) => {
    try {
      const res = await apiRequest("PUT", `/api/tasks/${id}`, updates);
      const updated = await res.json();
      updateGlobalTasks(globalTasks.map(t => t.id === id ? updated : t));
      
      // Automatic backup on detail update
      const blob = new Blob([JSON.stringify(globalTasks, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `diary_data_${format(new Date(), "yyyy-MM-dd")}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      return updated;
    } catch (e) {
      console.error("Failed to update task on backend", e);
    }
  }, []);

  const deleteTask = useCallback(async (id: number) => {
    try {
      await apiRequest("DELETE", `/api/tasks/${id}`);
      updateGlobalTasks(globalTasks.filter(t => t.id !== id));
    } catch (e) {
      console.error("Failed to delete task on backend", e);
    }
  }, []);

  const getTasksByDate = (date: string) => {
    return tasks.filter((t) => t.date === date);
  };

  const getOverdueTasks = (today: string) => {
    return tasks.filter((t) => 
      !t.completed && 
      !t.cancelled && 
      isBefore(parseISO(t.date), parseISO(today))
    );
  };

  return {
    tasks,
    addTask,
    updateTask,
    deleteTask,
    getTasksByDate,
    getOverdueTasks,
    getAllTasks: () => tasks,
  };
}
