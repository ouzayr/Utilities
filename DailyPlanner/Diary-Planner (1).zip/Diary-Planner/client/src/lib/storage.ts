import { useState, useEffect } from "react";
import { Task, InsertTask } from "@shared/schema";
import { format, isBefore, parseISO } from "date-fns";

const STORAGE_KEY = 'diary-storage-v1';

export function useTaskStore() {
  const [tasks, setTasks] = useState<Task[]>([]);

  // Initialize from localStorage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setTasks(parsed.tasks || []);
      } catch (e) {
        console.error("Failed to parse storage", e);
      }
    }
  }, []);

  // Persist to localStorage
  const saveTasks = (newTasks: Task[]) => {
    setTasks(newTasks);
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ tasks: newTasks }));
    
    // Automatic backup on save as requested
    const blob = new Blob([JSON.stringify(newTasks, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `diary_data_${format(new Date(), "yyyy-MM-dd")}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const addTask = (insertTask: InsertTask) => {
    const newTask: Task = {
      ...insertTask,
      id: Math.floor(Math.random() * 1000000),
      completed: insertTask.completed ?? false,
      cancelled: insertTask.cancelled ?? false,
      category: insertTask.category ?? null,
      client: insertTask.client ?? null,
      tags: insertTask.tags ?? [],
      notes: insertTask.notes ?? null,
      handwrittenNotes: insertTask.handwrittenNotes ?? null,
      attachments: insertTask.attachments ?? [],
      rescheduleHistory: insertTask.rescheduleHistory ?? [],
      createdAt: new Date(),
    } as Task;
    saveTasks([...tasks, newTask]);
    return newTask;
  };

  const updateTask = (id: number, updates: Partial<InsertTask>) => {
    const newTasks = tasks.map((t) => (t.id === id ? { ...t, ...updates } : t)) as Task[];
    saveTasks(newTasks);
    return newTasks.find(t => t.id === id);
  };

  const deleteTask = (id: number) => {
    saveTasks(tasks.filter((t) => t.id !== id));
  };

  const getTasksByDate = (date: string) => {
    return tasks.filter((t) => t.date === date);
  };

  const getOverdueTasks = (today: string) => {
    return tasks.filter((t) => 
      !t.completed && 
      !t.cancelled && 
      isBefore(parseISO(t.date), parseISO(today))
    );
  };

  return {
    tasks,
    addTask,
    updateTask,
    deleteTask,
    getTasksByDate,
    getOverdueTasks,
    getAllTasks: () => tasks,
  };
}
