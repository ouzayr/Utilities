import type { Express } from "express";
import type { Server } from "http";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // All logic moved to client-side storage (Zustand + LocalStorage)
  // This file is now a placeholder for the server structure
  return httpServer;
}
