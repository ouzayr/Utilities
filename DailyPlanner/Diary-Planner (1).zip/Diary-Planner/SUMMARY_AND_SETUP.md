# Task Tracker - Minimalist Journal Experience

This project is a minimalist, physical-journal-inspired task tracker. It features a daily log, a 7-day weekly planner, and an insights dashboard, all powered by a private, browser-based storage system.

## Features Implemented

1.  **Daily Journal View**: A focused view for the current day's tasks with a clean, serif-typography aesthetic.
2.  **Weekly/Monthly/Yearly Planner**: A multi-view calendar system to plan and review tasks across different time scales (7-day week view).
3.  **Insights Dashboard**: Weekly statistics on task completion and productivity rhythm with historical navigation.
4.  **Morning Replan**: A forced modal on app load that requires you to review uncompleted tasks from previous days (Move to Today, Mark Completed, or Cancel).
5.  **Task Details**: Deep-dive into tasks with categories, clients, multiple tags, typed notes, and a **handwriting/drawing canvas** for stylus users.
6.  **Media Attachments**: Ability to take photos or attach images directly to specific tasks.
7.  **Data Persistence**: All data is stored in your browser's `localStorage` using standard JavaScript, making it private and server-independent.
8.  **Automatic Backups**: The app automatically generates and downloads a JSON backup of your data whenever you save task details.
9.  **Reschedule History**: The JSON data tracks every time a task was moved to a different date.

## Local Setup Guide

Follow these steps to run the application on your local machine after downloading the code.

### Prerequisites

- **Node.js**: Version 18 or higher.
- **npm**: Usually comes with Node.js.

### 1. Extract and Navigate
Unzip the downloaded code and open your terminal/command prompt in the root directory of the project.

### 2. Install Dependencies
Run the following command to install all necessary packages:
```bash
npm install
```

### 3. Configuration
Since the app now uses browser storage and has no backend database requirements, you don't need to set up PostgreSQL or environment variables for the core functionality to work locally.

### 4. Start the Application
Run the development server:
```bash
npm run dev
```

The application will typically be available at `http://localhost:5173` (or the port specified in your terminal).

## Tech Stack
- **Frontend**: React, Vite, Tailwind CSS, Shadcn UI.
- **Icons**: Lucide React.
- **Charts**: Recharts.
- **Date Handling**: date-fns.
- **Storage**: Standard Browser LocalStorage (Custom Hook).
- **Styling**: Custom serif-first design system.
